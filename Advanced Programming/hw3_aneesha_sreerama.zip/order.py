

class Order:

    def __init__(self,  priority, product, quantity, o_id):
        self.priority = priority
        self.product = product
        self.quantity = quantity
        self.id = o_id

    def __str__(self):
        return f"ID: {self.get_id()}, Priority: {self.get_priority()}, " \
               f"Product: {self.get_product()} Quantity: {self.get_quantity()}"

    def __repr__(self):
        return f"(ID: {self.get_id()}, Priority: {self.get_priority()}, " \
               f"Product: {self.get_product()} Quantity: {self.get_quantity()})"

    # Getters
    def get_id(self):
        return self.id

    def get_priority(self):
        return self.priority

    def get_product(self):
        return self.product

    def get_quantity(self):
        return self.quantity

