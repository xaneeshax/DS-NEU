from pymongo import MongoClient
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import requests
import wordcloud as wc
import matplotlib.pyplot as plt
from main import get_article_data

client = MongoClient()
client.drop_database("articles")

# for testing purposes (if needed)
# API_KEY = os.environ['NYT_API_KEY']
API_KEY = 'M1GrXzKTy5yMfA2lnM5eFeSFy8KoetdS'
db = client.articles


class ArticleAnalyzer:

    @staticmethod
    def add_nov_articles(year):
        """ Uses the NYT Archive API to create an articles collection in MongoDB """
        metadata = []

        # Use requests library
        nyt_url = f"https://api.nytimes.com/svc/archive/v1/{year}/11.json"
        search_params = {"api-key": API_KEY}

        articles = requests.get(nyt_url, params=search_params)
        articles = articles.json()

        # Get required metadata from the response
        for article in articles['response']['docs']:
            info = {'publish_date': article['pub_date'][:-5],
                    'year': year,
                    'lead_paragraph': article["lead_paragraph"],
                    'news_category': article['news_desk'],
                    'word_count': int(article['word_count']),
                    'article_url': article['web_url']
                    }

            metadata.append(info)

        # Insert all articles for the year
        db.articles.insert_many(metadata)

    @staticmethod
    def articles_published():
        """ Determines the number of articles published per year and visualizes the data """
        # Query in Mongo Shell: db.articles.aggregate({$group:{_id:"$year",count:{$sum:1}}})

        # Pymongo command to aggregate articles published over year
        cursor = db.articles.aggregate([{"$group": {"_id": "$year",
                                                    "count": {"$sum": 1}
                                                    }
                                         }])

        # Converts data into a dictionary and sorts by year
        counts = {}
        for document in cursor:
            counts[document["_id"]] = document['count']
        counts = dict(sorted(counts.items(), key=lambda item: item[0]))

        # Create and customize a line plot using plotly
        fig = go.Figure()

        fig.add_trace(go.Scatter(x=list(counts.keys()), y=list(counts.values()),
                                 mode='lines+markers',
                                 line=dict(color='rgb(8,48,107)', width=2)))

        fig.update_layout(title='Number of Articles Published each year in November by New York Times',
                          xaxis_title='Year',
                          yaxis_title='Articles Published',
                          template='plotly_white',
                          font=dict(
                              family="Courier New, monospace",
                              size=14,
                              color="black"
                            )
                          )
        fig.show()

    @staticmethod
    def political_articles_published():
        """ How have the number of politics articles changed in election month (November) over the decade? """
        # Query in Mongo Shell: db.articles.distinct("news_category")
        # Query in Mongo Shell: db.articles.find({news_category: "Politics"})

        mentions = {}
        # Pymongo command
        for a in db.articles.find({"news_category": "Politics"}):
            if a["year"] in mentions.keys():
                mentions[a["year"]] += 1
            else:
                mentions[a["year"]] = 0

        mentions = dict(sorted(mentions.items(), key=lambda item: item[0]))

        # Create and customize a line plot using plotly
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=list(mentions.keys()), y=list(mentions.values()),
                                 fill='tozeroy', line=dict(width=1, color='rgb(8,48,107)')))

        fig.update_layout(title='Politics Related Articles Published each year in November by New York Times',
                          xaxis_title='Year',
                          yaxis_title='Articles Published',
                          template='plotly_white',
                          font=dict(
                              family="Courier New, monospace",
                              size=14,
                              color="black"
                          )
                          )

        fig.show()

    @staticmethod
    def popular_news_categories(start_year, end_year):
        """ Get the popular news categories in Election Month each year """

        data = {}
        # Pymongo command to get the distinct news categories
        categories = db.articles.distinct("news_category")

        for year in range(start_year, end_year + 1):
            data[year] = {cat: 0 for cat in categories}
            # Pymongo command to filter by year
            for a in db.articles.find({'year': year}):
                if a["news_category"] != '':
                    data[year][a["news_category"]] += 1

        # Create and customize a subplot of bar charts using plotly
        num_rows = 2
        num_cols = 5

        # Create the subplot
        fig = make_subplots(
            rows=num_rows, cols=num_cols,
            subplot_titles=tuple([str(year) for year in range(start_year, end_year + 1)]))

        year = start_year
        for row in range(1, num_rows + 1):
            for col in range(1, num_cols + 1):
                # Get the top genres
                top_genres = dict(sorted(data[year].items(), key=lambda item: item[1])[::-1][:5])

                fig.add_trace(go.Bar(x=list(top_genres.keys())[:5], y=list(top_genres.values())[:5]),
                              row=row, col=col)

                year += 1

        # Label an Title the PLot
        fig.update_layout(height=700, width=1000, showlegend=False, template="plotly_white",
                          title_text=f"Top Genres of November from {start_year}-{end_year}")

        fig.update_traces(marker_color='rgb(158,202,225)', marker_line_color='rgb(8,48,107)',
                          marker_line_width=1.5, opacity=0.6)

        fig.show()

    @staticmethod
    def get_article_data(year):
        """ Turn the each article summary into a long string of words """

        words = ''
        # pymongo command to simply fetch articles of the given year
        for a in db.articles.find({'year': year}):
            words += a['lead_paragraph'] + ' '

        return words

    @staticmethod
    def visualize_article_content(start_year):
        """ Generate word clouds using article content for each month """

        cloud = wc.WordCloud(width=600, height=600,
                             colormap='Dark2',
                             min_word_length=5,
                             min_font_size=6,
                             background_color='white')

        fig = plt.figure(figsize=(12, 12))
        columns = 5
        rows = 2

        # Word cloud for each year in dataset
        year = start_year
        for i in range(1, columns * rows + 1):
            img = cloud.generate(get_article_data(year))
            fig.add_subplot(rows, columns, i)
            plt.axis('off')
            plt.title(str(year))
            year += 1
            plt.imshow(img)

        # Display to screen
        plt.show(block=True)
        plt.interactive(False)


def main():

    # Specify year range
    start_year = 2012
    end_year = 2021

    # Retrieve articles from start to end years
    analyzer = ArticleAnalyzer()
    for year in range(start_year, end_year + 1):
        analyzer.add_nov_articles(year)

    # Number of Articles published each year in November by New York Times
    analyzer.articles_published()

    # Number of Political Articles Published by NYT
    analyzer.political_articles_published()

    # Popular News Categories by Year
    analyzer.popular_news_categories(start_year, end_year)

    # Visualize the content of the articles
    analyzer.visualize_article_content(start_year)


if __name__ == "__main__":
    main()
