

class Order:

    def __init__(self, order_date, priority, quantity):
        self.order_date = order_date
        self.priority = priority
        self.quantity = quantity

    def __str__(self):
        return f"Order Date: {self.get_order_date()}, Priority: {self.get_priority()}, Quantity: {self.get_quantity()}"

    # Getters
    def get_order_date(self):
        return self.order_date

    def get_priority(self):
        return self.priority

    def get_quantity(self):
        return self.quantity

    # Setters
    def set_quantity(self, quantity):
        self.quantity = quantity

    def set_priority(self, priority):
        self.priority = priority

    def set_order_date(self, order_date):
        self.order_date = order_date