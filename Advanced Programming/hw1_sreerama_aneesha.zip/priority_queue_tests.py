from dstruct.priority_queue import PriorityQueue
from dstruct.order import Order


def test_constructor():

    order_queue = PriorityQueue()
    assert isinstance(order_queue, PriorityQueue), "not a priority queue"


def test_size():
    order_queue = PriorityQueue()
    o1 = Order("2021-09-13", "H", 22)
    o2 = Order("2021-09-14", "H", 19)
    order_queue.enqueue(o1)
    order_queue.enqueue(o2)

    assert order_queue.size() == 2, "Inaccurate size"


def test_enqueue():
    order_queue = PriorityQueue()
    o1 = Order("2021-09-13", "H", 22)
    o2 = Order("2021-09-14", "H", 19)

    order_queue.enqueue(o1)
    assert order_queue.size() == 1, "Enqueue did not add element"

    order_queue.enqueue(o2)
    assert order_queue.size() == 2, "Enqueue did not add elemet"


def test_dequeue():
    order_queue = PriorityQueue()
    o1 = Order("2021-09-13", "H", 22)
    o2 = Order("2021-09-14", "H", 19)
    order_queue.enqueue(o1)
    order_queue.enqueue(o2)

    order_queue.dequeue()
    assert order_queue.size() == 1
    order_queue.dequeue()
    assert order_queue.size() == 0



def test_peek():
    order_queue = PriorityQueue()
    o1 = Order("2021-09-13", "H", 22)
    o2 = Order("2021-09-14", "L", 19)

    assert order_queue.peek() == None, "Order Queue is not Empty"

    order_queue.enqueue(o2)
    assert order_queue.peek() == o2, "Peek did not show the only element"

    order_queue.enqueue(o1)
    assert order_queue.peek() == o1, "Peek did not show the highest priority element"


def test_is_empty():
    order_queue = PriorityQueue()
    assert order_queue.is_empty() == True, "Order Queue is not empty"

    o1 = Order("2021-09-13", "H", 22)
    order_queue.enqueue(o1)
    assert order_queue.is_empty() == False, " Order Queue is empty"


def test_clear():
    order_queue = PriorityQueue()
    o1 = Order("2021-09-13", "H", 22)
    o2 = Order("2021-09-14", "H", 19)

    order_queue.enqueue(o1)
    order_queue.enqueue(o2)
    order_queue.clear()

    assert order_queue.size() == 0, "Clear operator did not work"