from dstruct.order_manager import OrderManager


def test_constructor():
    om = OrderManager()
    assert isinstance(om, OrderManager), "not an order manager"


def test_read_json():
    om = OrderManager()
    om.read_json('orders.json')

    # There 87 orders in the order queue
    om.order_queue.size() == 87, "Data was read incorrectly"



