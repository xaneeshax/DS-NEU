from dstruct.order import Order


def test_constructor():
    o = Order("2021-09-13", "H", 22)

    assert isinstance(o, Order), "not an order"


def test_getters():

    order = Order("2021-09-13", "H", 22)
    assert order.get_order_date() == "2021-09-13", "Order Date Getter is Incorrect"
    assert order.get_priority() == "H", "Order Priority Getter is Incorrect"
    assert order.get_quantity() == 22, "Order Quantity Getter is Incorrect"


def test_setters():
    order = Order("2021-09-13", "H", 22)
    order.set_order_date("2021-09-15")
    order.set_priority("L")
    order.set_quantity(100)

    assert order.order_date == "2021-09-15", "Order Date Setter is Incorrect"
    assert order.priority == "L", "Order Priority Setter is Incorrect"
    assert order.quantity == 100, "Order Quantity Setter is Incorrect"




